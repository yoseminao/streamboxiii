import xbmc, xbmcgui, xbmcvfs
import shutil
import urllib2,urllib
import sys

f = xbmcvfs.File('special://home/streamboxiii.mx3-license')
b = f.read()
f.close()

class CheckLicense(xbmcgui.Window):
  def __init__(self):  
    dialog = xbmcgui.Dialog()
    if dialog.ok("", b):
		print "box closed" #need to get this part working

checklicense = CheckLicense()
del checklicense