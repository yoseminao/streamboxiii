import xbmc, xbmcgui
import shutil
import urllib2,urllib
import sys

class Reboot(xbmcgui.Window):
  def __init__(self):  
    dialog = xbmcgui.Dialog()
    if dialog.yesno("STREAMBOXIII MX3", "Do you want to restart now?"):
		xbmc.executebuiltin("Reboot")

reboot = Reboot()
del reboot