import xbmc, xbmcgui
import shutil
import urllib2,urllib
import time

localtxt1 = 'Update STREAMBOXIII to latest version'
localtxt2 = 'STREAMBOXIII successfully updated!'
localtxt3 = 'Updating. Please Wait...'
localtxt4 = 'Installing Updates!'

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Update/Recover STREAMBOXIII","Downloading & Installing. Please Wait...",'')
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print 'Downloaded '+str(percent)+'%'
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()
		
class Update(xbmcgui.Window):
  def __init__(self):  
    dialog = xbmcgui.Dialog()
    if dialog.yesno("", localtxt1):
        url = 'http://streamboxiii.ziicreater.com/update.zip'
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib=os.path.join(path, 'update.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home',''))
        xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))
       
	xbmc.executebuiltin("Notification("+localtxt3+",STREAMBOXIII MX3)")
	xbmc.executebuiltin("Notification("+localtxt4+",STREAMBOXIII MX3)")
   	xbmc.executebuiltin("Notification("+localtxt2+",STREAMBOXIII MX3)")
	time.sleep(15)
	xbmc.executebuiltin("RunScript(special://skin/resources/reboot.py)")
		
	#
	#	time.sleep(15)
	#
    #    time.sleep(15)
   	#
	#	
	#

update = Update()
del update