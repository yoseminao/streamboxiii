############################################################################
#
#  Copyright 2014 Wilfred Helmig - kaosBOX
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
# 
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
# 
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
############################################################################


import xbmc, xbmcgui
import shutil

localtxt1 = xbmc.getLocalizedString(31067)
localtxt2 = xbmc.getLocalizedString(31073)
localtxt3 = xbmc.getLocalizedString(31074)

destpath=xbmc.translatePath(os.path.join('special://home/addons/packages',''))

class MyClass(xbmcgui.Window):
  def __init__(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno(localtxt1, localtxt3):
      shutil.rmtree(destpath)
      os.mkdir(destpath)
      self.close()

      xbmc.executebuiltin("Notification("+localtxt2+",STREAMBOXIII Maintenance.)")


mydisplay = MyClass()
del mydisplay

